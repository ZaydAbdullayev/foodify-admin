export const ClearForm = (element) => {
  document.getElementById(element).reset();
};
