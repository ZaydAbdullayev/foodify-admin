import React from "react";
import "./allRes.css";

export const AllRes = () => {
  return (
    <div className="allRes_box">
      <h1>All Restaurant</h1>
    </div>
  );
};
