export const ClearForm = (selector) => {
  return document.querySelector(selector).reset();
};
